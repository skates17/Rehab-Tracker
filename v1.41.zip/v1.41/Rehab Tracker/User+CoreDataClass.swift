//
//  User+CoreDataClass.swift
//  Rehab Tracker
//
//  Created by Sean Kates on 12/5/16.
//  Copyright © 2016 CS 275 Project Group 6. All rights reserved.
//

import Foundation
import CoreData


public class User: NSManagedObject {

}
